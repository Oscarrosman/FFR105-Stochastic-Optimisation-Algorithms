function mutatedIndividual = Mutate(individual, mutationProbability);
