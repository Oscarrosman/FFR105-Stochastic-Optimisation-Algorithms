function newIndividuals = Cross(individual1, individual2)
